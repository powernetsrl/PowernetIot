
import http from "http";
import { parse as parseUrl } from "url";
import fs from "fs";
import path from "path";

const PORT = process.env.PORT || 5000;
const HA_MODE = (process.env.HA_MODE || "mock").toLowerCase(); // mock | live
const DATA_DIR = process.env.DATA_DIR || path.resolve(process.cwd(), "../data");
const VERSION = "0.3.0";

fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_FILE = path.join(DATA_DIR, "storage.json");
const defaultDb = { gateways: [], condoMap: {}, tariffe: {}, updatedAt: new Date().toISOString() };

function readDb(){
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); } catch { return { ...defaultDb }; }
}
function writeDb(db){
  db.updatedAt = new Date().toISOString();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  return db;
}

function send(res, code, obj){
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,Authorization"
  });
  res.end(body);
}

async function jsonBody(req){
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (c) => data += c);
    req.on("end", () => {
      try { resolve(JSON.parse(data || "{}")); } catch { resolve({}); }
    });
  });
}

async function haRequest(gw, endpoint){
  if (HA_MODE !== "live") {
    // mock reply
    if (endpoint === "/api/") return { ok: true, message: "API running." };
    if (endpoint.startsWith("/api/states")) {
      return [
        { entity_id: "sensor.acqua_app1_total", state: "123", attributes: { friendly_name: "App 1", unit_of_measurement: "m³", device_class: "water" } },
        { entity_id: "sensor.acqua_app2_total", state: "456", attributes: { friendly_name: "App 2", unit_of_measurement: "m³", device_class: "water" } },
        { entity_id: "sensor.gas_a1_total",       state: "789", attributes: { friendly_name: "Gas A1", unit_of_measurement: "m³", device_class: "gas" } }
      ];
    }
    return { ok: true };
  }
  const url = new URL(endpoint, gw.url).toString();
  const r = await fetch(url, {
    headers: { "Authorization": `Bearer ${gw.token}` }
  });
  if (!r.ok) throw new Error(`HA ${r.status}`);
  const ct = r.headers.get("content-type") || "";
  if (ct.includes("application/json")) return await r.json();
  return await r.text();
}

function filterStates(states, match){
  if (!match) return states;
  const m = match.toLowerCase();
  return states.filter(s => String(s.entity_id || "").toLowerCase().includes(m) ||
                            String(s.attributes?.friendly_name || "").toLowerCase().includes(m));
}

// Router
const server = http.createServer(async (req, res) => {
  const { pathname, query } = parseUrl(req.url, true);

  if (req.method === "OPTIONS") return send(res, 200, { ok: true });

  try {
    // Health & meta
    if (req.method === "GET" && pathname === "/api/health") {
      return send(res, 200, { ok: true, service: "powernet-backend", ha_mode: HA_MODE });
    }
    if (req.method === "GET" && pathname === "/api/version") {
      return send(res, 200, { version: VERSION });
    }

    // Tariffe
    if (pathname === "/api/tariffe") {
      const db = readDb();
      if (req.method === "GET") return send(res, 200, db.tariffe || {});
      if (req.method === "PUT") {
        const body = await jsonBody(req);
        db.tariffe = body || {};
        writeDb(db);
        return send(res, 200, { ok: true });
      }
    }

    // Gateways CRUD
    if (pathname === "/api/ha/gateways" && req.method === "GET") {
      const db = readDb();
      return send(res, 200, { gateways: db.gateways || [] });
    }
    if (pathname === "/api/ha/gateways" && req.method === "POST") {
      const body = await jsonBody(req);
      if (!body || !body.id || !body.url || !body.token) return send(res, 400, { ok: false, error: "missing_fields" });
      const db = readDb();
      if ((db.gateways||[]).some(g => g.id === body.id)) return send(res, 409, { ok: false, error: "exists" });
      db.gateways = [...(db.gateways||[]), { id: body.id, name: body.name || body.id, url: body.url, token: body.token, verify_tls: body.verify_tls !== false, timeout_ms: Number(body.timeout_ms||8000) }];
      writeDb(db);
      return send(res, 201, { ok: true });
    }
    if (pathname.startsWith("/api/ha/gateways/") && req.method === "PUT") {
      const id = decodeURIComponent(pathname.split("/").pop());
      const body = await jsonBody(req);
      const db = readDb();
      const idx = (db.gateways||[]).findIndex(g => g.id === id);
      if (idx < 0) return send(res, 404, { ok: false, error: "not_found" });
      db.gateways[idx] = { ...db.gateways[idx], ...body };
      writeDb(db);
      return send(res, 200, { ok: true });
    }
    if (pathname.startsWith("/api/ha/gateways/") && req.method === "DELETE") {
      const id = decodeURIComponent(pathname.split("/").pop());
      const db = readDb();
      db.gateways = (db.gateways||[]).filter(g => g.id !== id);
      writeDb(db);
      return send(res, 200, { ok: true });
    }

    // HA health & states (by gateway)
    if (pathname === "/api/ha/health" && req.method === "GET") {
      const gwId = query.gw;
      const db = readDb();
      const gw = (db.gateways||[]).find(g => g.id === gwId);
      if (!gw) return send(res, 404, { ok: false, error: "gateway_not_found" });
      try {
        const r = await haRequest(gw, "/api/");
        return send(res, 200, { ok: true, response: r });
      } catch (e) {
        return send(res, 502, { ok: false, error: String(e.message||e) });
      }
    }
    if (pathname === "/api/ha/states" && req.method === "GET") {
      const gwId = query.gw;
      const match = query.match || "";
      const db = readDb();
      const gw = (db.gateways||[]).find(g => g.id === gwId);
      if (!gw) return send(res, 404, { ok: false, error: "gateway_not_found" });
      try {
        const states = await haRequest(gw, "/api/states");
        const filtered = Array.isArray(states) ? filterStates(states, match) : [];
        return send(res, 200, { ok: true, items: filtered });
      } catch (e) {
        return send(res, 502, { ok: false, error: String(e.message||e) });
      }
    }

    // Condo ↔ Gateway map
    if (pathname === "/api/condomini/map" && req.method === "GET") {
      const db = readDb();
      return send(res, 200, { map: db.condoMap || {} });
    }
    if (pathname === "/api/condomini/map" && req.method === "PUT") {
      const body = await jsonBody(req);
      const db = readDb();
      db.condoMap = body || {};
      writeDb(db);
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { ok: false, error: "not_found" });
  } catch (e) {
    return send(res, 500, { ok: false, error: String(e.message || e) });
  }
});

server.listen(PORT, () => {
  console.log(`✅ Powernet backend ${HA_MODE} avviato su porta ${PORT}`);
});
