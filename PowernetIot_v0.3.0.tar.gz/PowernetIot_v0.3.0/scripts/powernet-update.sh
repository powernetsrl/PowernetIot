#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${REPO_URL:-https://github.com/powernetsrl/PowernetIot.git}"
WORK_DIR="${WORK_DIR:-/opt/powernet}"
BRANCH="${BRANCH:-main}"

if [[ ! -d "$WORK_DIR/.git" ]]; then
  echo "[i] Clonazione iniziale in $WORK_DIR"
  sudo rm -rf "$WORK_DIR"
  sudo git clone "$REPO_URL" "$WORK_DIR"
fi

cd "$WORK_DIR"
sudo git fetch --all
sudo git reset --hard "origin/${BRANCH}"

if command -v npm >/dev/null 2>&1; then
  npm --prefix "$WORK_DIR" ci || npm --prefix "$WORK_DIR" install
fi

if systemctl is-enabled --quiet powernet-backend.service 2>/dev/null; then
  sudo systemctl restart powernet-backend.service || true
fi

if [[ -d "$WORK_DIR/frontend" && -d /var/www/powernet ]]; then
  sudo rsync -a --delete "$WORK_DIR/frontend/" /var/www/powernet/
fi

echo '{"ok":true,"updated":true}'
