# PowernetIot v0.3.0

- Backend Node (HTTP core, no Express) con integrazione Home Assistant **mock/live**
- CRUD Gateways, health check, elenco stati `/api/states`
- Mappa Condominio↔Gateway
- Aggiornamento online via systemd oneshot

## Avvio rapido (mock)

```bash
sudo apt-get update && sudo apt-get install -y nodejs npm
cd /opt/powernet
npm ci || npm install
PORT=5000 HA_MODE=mock node backend/server.js
```

## Live mode

```bash
sudo cp systemd/powernet-backend.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl edit powernet-backend.service
# Aggiungi in [Service]:
# Environment=HA_MODE=live
sudo systemctl restart powernet-backend
```

## Endpoints

- `GET  /api/health`
- `GET  /api/version`
- `GET  /api/tariffe`  / `PUT /api/tariffe`
- `GET  /api/ha/gateways`
- `POST /api/ha/gateways`  `{id,url,token,name?}`
- `PUT  /api/ha/gateways/:id`
- `DELETE /api/ha/gateways/:id`
- `GET  /api/ha/health?gw=ID`
- `GET  /api/ha/states?gw=ID&match=sensor.acqua`
- `GET  /api/condomini/map`
- `PUT  /api/condomini/map` `{ "c1":"ha-1" }`

## Admin UI (statica)
Copia `frontend/ha-admin.html` in `/var/www/powernet/` (Nginx) e apri `http://SERVER/ha-admin.html`.
